package pe.idat.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import pe.idat.entity.Notas;

public interface NotasRepository  extends JpaRepository<Notas, Integer>{

}
