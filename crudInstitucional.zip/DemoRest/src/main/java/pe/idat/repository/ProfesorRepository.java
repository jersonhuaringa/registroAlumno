package pe.idat.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import pe.idat.entity.Profesor;

public interface ProfesorRepository extends JpaRepository<Profesor, Integer> {

}
