package pe.idat.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import pe.idat.entity.Horario;

public interface HorarioRepository extends JpaRepository<Horario, Integer>{

}
